<a href="/">
    <img class="h-20" src="{{config('settings.logo')}}" alt="Logo" />
</a>
