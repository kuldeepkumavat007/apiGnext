

<!-- Display the name label -->
<div class="form-group text-center">
    <div class="form-control-plaintext"><strong>@{{ activeChat.name }}</strong></div>
</div>


