<?php

return [

    'name'              => 'Themes',
    'description'       => 'This is my awesome module',

];